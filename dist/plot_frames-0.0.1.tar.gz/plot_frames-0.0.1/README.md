# **Introduction**


# **References**

1. [https://github.com/petercorke/spatialmath-python](https://github.com/petercorke/spatialmath-python).

# **Credit**

Dr Frazer K. Noble
Department of Mechanical and Electrical Engineering  
Massey University  
Auckland
New Zealand  
L: https://www.linkedin.com/in/drfknoble/
G: https://github.com/drfknoble
